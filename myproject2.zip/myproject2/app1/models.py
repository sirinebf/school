from django.db import models
from django.urls import reverse

class Specialite(models.Model):
    id = models.AutoField(help_text='id de specialite', verbose_name='id de specialite', primary_key=True)
    name = models.CharField(max_length=200, help_text='Nom de specialite', verbose_name='Nom', null=True, blank=True)
    
    def get_absolute_url(self):
        return reverse('specialite-list')

    def __str__(self):
        return self.name

class Etudiant(models.Model):
    id = models.AutoField(help_text='id de l\etudiant', verbose_name='id de l\etudiant', primary_key=True)
    first_name = models.CharField(max_length=200, help_text='Nom de l\etudiant', verbose_name='Nom', null=True, blank=True)
    last_name = models.CharField(max_length=200, help_text='Nom de l\etudiant', verbose_name='Nom', null=True, blank=True)
    specialite = models.ForeignKey(Specialite, default=1, on_delete=models.CASCADE)
 

