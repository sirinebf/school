from django.shortcuts import render
from django.views.generic import DetailView, ListView, CreateView, UpdateView, DeleteView
from .models import *
from django.urls import reverse_lazy

class SpecialiteCreate(CreateView):
	model = Specialite
	fields = '__all__'

class SpecialiteList(ListView):
	model = Specialite
	
class SpecialiteUpdate(UpdateView):
	model = Specialite
	fields = '__all__'

class SpecialiteDelete(DeleteView):
	model = Specialite
	success_url = reverse_lazy('specialite-list')
