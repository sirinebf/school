from django.urls import path 
from . import views
urlpatterns = [
    path('specialite/create', views.SpecialiteCreate.as_view()),
    path('specialite/', views.SpecialiteList.as_view(),name='specialite-list'),
    path('specialite/update/<int:pk>', views.SpecialiteUpdate.as_view(), name='specialite-update'),
    path('specialite/delete/<int:pk>', views.SpecialiteDelete.as_view(), name="specialite-delete"),
]